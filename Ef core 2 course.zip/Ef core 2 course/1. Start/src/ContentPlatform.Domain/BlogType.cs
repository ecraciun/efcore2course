﻿namespace ContentPlatform.Domain
{
    public enum BlogType
    {
        Travel,
        Finance,
        Tech,
        Gaming,
        Cooking
    }
}