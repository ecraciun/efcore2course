﻿namespace ContentPlatform.Domain
{
    public class PostMetadata
    {
        public string Title { get; set; }
        public string Keywords { get; set; }
    }
}