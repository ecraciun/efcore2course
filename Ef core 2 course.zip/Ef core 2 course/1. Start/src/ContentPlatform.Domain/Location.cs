﻿namespace ContentPlatform.Domain
{
    public class Location
    {
        public int LocationId { get; set; }
        public string Address { get; set; }
        //public Publisher Publisher { get; set; }
    }
}