﻿namespace ContentPlatform.Domain
{
    public class BlogStatistics
    {
        public string Title { get; set; }
        public string Url { get; set; }
        public int PostCount { get; set; }
    }
}