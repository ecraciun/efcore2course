﻿using System.Collections.Generic;

namespace ContentPlatform.Domain
{
    public class Publisher
    {
        public Publisher()
        {
            Blogs = new List<Blog>();
            Authors = new List<Author>();
        }

        public int PublisherId { get; set; }
        public string Name { get; set; }
        public string MainWebsite { get; set; }
        public List<Blog> Blogs { get; set; }
        public List<Author> Authors { get; set; }
        public Location MainOffice { get; set; }
    }
}